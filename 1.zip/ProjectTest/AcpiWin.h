#include "Log.h"

AcpiWin::Log LOG(L"log.txt");
