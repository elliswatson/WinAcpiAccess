#include "AcpiNs.h"



std::string AcpiWin::AcpiNs::GetType(int type)
{


    return std::string();
}
